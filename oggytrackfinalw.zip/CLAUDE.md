# CLAUDE.md

This file provides repository context, architectural invariants, and workflow commands to Claude Code (`claude`) and Claude Projects when working in **oggytrack**.

## Project Overview

**oggytrack** is a local-first academic workspace built with React 19, TypeScript, Vite, and Tailwind CSS v4. It manages courses, conflict-free class timetables, attendance thresholds & recovery forecasting, assignments, academic holidays, and a unified live calendar.

## Essential Commands

```bash
npm install        # Install dependencies
npm run dev        # Start Vite dev server at http://localhost:3000
npm run lint       # Run TypeScript typecheck (tsc --noEmit)
npm test           # Run pure-logic unit tests (tsx + node:test)
npm run build      # Build production static bundle into dist/
npm run preview    # Preview production bundle locally
```

Always run `npm run lint && npm test && npm run build` after modifying TypeScript or React files to confirm zero regressions.

## Architecture & Directory Map

```text
src/
├── App.tsx                         # Auth session gate, active view state, desktop + mobile sidebar layout
├── types/
│   └── oggytrack.ts                # Core TypeScript domain models (UserProfile, Subject, ClassSession, etc.)
├── utils/
│   ├── academicCalculations.ts     # Pure attendance %, safe-to-miss buffer, recovery streak & what-if math
│   ├── academicCalculations.test.ts# Unit tests for attendance & forecasting formulas
│   ├── dateUtils.ts                # Local ISO date helpers, live clock hook (useLiveClock), calendar grid, .ics export
│   ├── dateUtils.test.ts           # Unit tests for date formatting & month grid calculations
│   └── storage.ts                  # Per-user localStorage persistence layer (db) + JSON backup/restore
└── components/
    ├── common/ModalShell.tsx       # Portal-based accessible modal wrapper (renders into document.body)
    ├── layout/
    │   ├── Sidebar.tsx             # Desktop persistent sidebar + mobile slide-out drawer navigation
    │   └── Navbar.tsx              # Sticky top bar with mobile menu trigger, search, notifications & quick actions
    ├── auth/AuthPage.tsx           # Local account sign-in & registration (example username: "oggy")
    ├── onboarding/                 # Interactive workspace onboarding wizard
    ├── dashboard/DashboardView.tsx # Daily schedule, attendance safeguard overview, upcoming tasks & holidays
    ├── timetable/                  # Weekly/daily timetable grid, conflict detection & CSV/JSON importer
    ├── subjects/SubjectsManager.tsx# Course catalog & target attendance thresholds
    ├── attendance/AttendanceView.tsx# Session attendance logging, safe-bunk buffer & what-if simulator
    ├── assignments/                # Assignment tracker with status, priority & course filtering
    ├── holidays/HolidaysManager.tsx# Holiday scheduling with optional class-suspension policy
    ├── calendar/CalendarView.tsx   # Live month calendar combining classes, assignments & holidays + .ics export
    ├── analytics/AnalyticsView.tsx # Dynamic semester telemetry, course health & attendance breakdown
    └── settings/SettingsView.tsx   # Profile editor, semester config, global target %, JSON export/import & reset
```

## Core Invariants & Conventions

1. **Per-User `localStorage` Scoping (`src/utils/storage.ts`)**:
   - Global account registry & session keys: `oggytrack_accounts`, `oggytrack_auth`, `oggytrack_current_user`, `oggytrack_settings`.
   - Every academic collection MUST remain scoped by `<userId>` (`oggytrack_subjects_<userId>`, `oggytrack_timetable_<userId>`, `oggytrack_attendance_<userId>`, `oggytrack_assignments_<userId>`, `oggytrack_holidays_<userId>`, `oggytrack_notifications_<userId>`) so multiple local accounts stay isolated.
   - Whenever adding a new persisted entity, include it in `db.exportAllData`, `db.importAllData`, and `db.clearCurrentUserAcademicData`.

2. **Attendance Math Rules (`src/utils/academicCalculations.ts`)**:
   - `cancelled` sessions do not count toward conducted (`total`) or attended (`present + late`) counts.
   - When `conducted === 0`, attendance percentage MUST return `0` (with status `"No Classes Yet"`), never `100%`.
   - Safe-to-miss ("safe bunk") buffer: `Math.floor((attended - targetRatio * conducted) / targetRatio)`.
   - Consecutive classes needed to recover target: `Math.ceil((targetRatio * conducted - attended) / (1 - targetRatio))`.

3. **Local Dates & Live Time (`src/utils/dateUtils.ts`)**:
   - Always format calendar dates in the user's **local timezone** via `formatDateISO(date)` (`YYYY-MM-DD`). Avoid `new Date().toISOString().slice(0, 10)` because UTC conversion shifts dates near midnight in non-UTC timezones.
   - Use `useLiveClock()` for real-time clock/date displays so views stay current across midnight rollovers.

4. **Modals & Overlays (`src/components/common/ModalShell.tsx`)**:
   - All dialogs and creation/edit forms MUST use `<ModalShell>` (which portals to `document.body`) so parent `overflow` or `backdrop-filter` containers never clip form inputs or headers.

5. **Responsive Navigation (`Sidebar.tsx` + `Navbar.tsx`)**:
   - Desktop (`lg:` and up) renders a fixed left sidebar (`w-64`).
   - Mobile (`< lg`) uses the hamburger menu button in `Navbar.tsx` to open the left slide-out drawer inside `Sidebar.tsx` (no bottom tab bar).

6. **Styling & Accessibility**:
   - Tailwind CSS v4 is configured via `@import "tailwindcss";` in `src/index.css`. Avoid inline `style={{ ... }}` objects unless dynamically computing widths/progress bars.
   - Use semantic `<button>`, `<label>`, `<input>`, `<select>`, and `aria-label` on icon-only controls.
   - Keep `"oggy"` / `"Oggy"` as the default example placeholder in auth/onboarding UI.
